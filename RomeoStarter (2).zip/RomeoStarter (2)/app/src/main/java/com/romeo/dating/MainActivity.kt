package com.romeo.dating

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val RomeoRed = Color(0xFFD81B60)
private val RomeoPink = Color(0xFFFFF7F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RomeoApp() }
    }
}

@Composable
fun RomeoApp() {
    var screen by remember { mutableStateOf("welcome") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = RomeoRed,
            background = RomeoPink,
            surface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = RomeoPink) {
            when (screen) {
                "welcome" -> WelcomeScreen { screen = "age" }
                "age" -> AgeScreen(
                    onContinue = { screen = "auth" },
                    onExit = { screen = "welcome" }
                )
                "auth" -> AuthScreen { screen = "profile" }
                "profile" -> ProfileScreen { screen = "discover" }
                else -> DiscoverScreen()
            }
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("ROMEO", fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, color = RomeoRed)
        Spacer(Modifier.height(8.dp))
        Text("Find your connection.", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Meet people who are looking for the same kind of connection.",
            textAlign = TextAlign.Center,
            color = Color.DarkGray
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(28.dp)
        ) { Text("Get started", fontSize = 17.sp) }
    }
}

@Composable
fun AgeScreen(onContinue: () -> Unit, onExit: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("18+", fontSize = 58.sp, fontWeight = FontWeight.ExtraBold, color = RomeoRed)
        Spacer(Modifier.height(12.dp))
        Text("Romeo is for adults only.", fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            "You must be at least 18 years old to use Romeo. By continuing, you confirm that you meet this requirement.",
            textAlign = TextAlign.Center,
            color = Color.DarkGray
        )
        Spacer(Modifier.height(30.dp))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(28.dp)
        ) { Text("I am 18 or older") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = onExit,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(28.dp)
        ) { Text("Exit") }
    }
}

@Composable
fun AuthScreen(onContinue: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Create your Romeo account", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(email, { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Email") })
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(password, { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Password") })
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(28.dp)
        ) { Text("Continue") }
    }
}

@Composable
fun ProfileScreen(onContinue: () -> Unit) {
    var gender by remember { mutableStateOf("") }
    var seeking by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Set up your profile", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("I am")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(gender == "Man", { gender = "Man" }, label = { Text("Man") })
            FilterChip(gender == "Woman", { gender = "Woman" }, label = { Text("Woman") })
        }
        Spacer(Modifier.height(18.dp))
        Text("I am looking for")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(seeking == "Women", { seeking = "Women" }, label = { Text("Women") })
            FilterChip(seeking == "Men", { seeking = "Men" }, label = { Text("Men") })
        }
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onContinue,
            enabled = gender.isNotBlank() && seeking.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(28.dp)
        ) { Text("Save and continue") }
    }
}

@Composable
fun DiscoverScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Discover", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = RomeoRed)
        Spacer(Modifier.height(30.dp))
        Card(
            modifier = Modifier.fillMaxWidth().height(360.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Your first profiles will appear here.",
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Like profiles to create mutual matches.", color = Color.DarkGray)
    }
}
