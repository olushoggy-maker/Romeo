# Romeo Dating App — Starter

Android starter project for Romeo, an 18+ dating app.

## Firebase
The supplied `google-services.json` is already placed in `app/`.

Project:
- Firebase project ID: `romeo-201a9`
- Android package: `com.romeo.dating`

## First screens
Welcome → 18+ confirmation → account form → gender/preferences → Discover

## Open
Open this folder in Android Studio, let Gradle sync, then run the `app` configuration on an Android device/emulator.

## Next implementation
1. Connect the email/password form to Firebase Authentication.
2. Save profiles to Cloud Firestore.
3. Add photo upload using Firebase Storage.
4. Build the matching/likes system.
5. Add real-time chat, notifications, report and block.
